# AngelHack 2019 Umoni. :money_with_wings: 
[img](#public/assets/img/LOGOFINALNEGROPNG.png)

## Golang WebApp for managing Umonis backend